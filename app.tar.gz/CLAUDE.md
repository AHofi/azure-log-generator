# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Azure Log Generator is a high-volume log generation tool for testing Azure Application Insights daily cap notifications. It's a Node.js/Express application deployed to Azure App Service that generates configurable telemetry data (logs, metrics, events) to understand Application Insights behavior when approaching daily data ingestion limits.

## Common Commands

```bash
# Development
npm install              # Install dependencies
npm run dev             # Run with auto-reload (nodemon)
npm start               # Production start

# Code Quality
npm run lint            # Run ESLint
npm run lint:fix        # Auto-fix linting issues

# Testing (tests not yet implemented)
npm test                # Run Jest tests
npm run test:watch      # Run tests in watch mode

# Local Setup
cp .env.example .env    # Create environment config
# Then add your APPLICATIONINSIGHTS_CONNECTION_STRING to .env
```

## Architecture Overview

### Core Components

1. **app.js** - Express server entry point
   - Initializes Application Insights via `appInsights.js`
   - Creates `LogGenerator` instance from `logGenerator.js`
   - Exposes REST API endpoints for log generation control
   - Handles graceful shutdown on SIGTERM/SIGINT

2. **appInsights.js** - Application Insights configuration
   - Must initialize before any logging occurs
   - Configures telemetry processors, sampling, and batching
   - Tracks memory metrics every 30 seconds
   - Returns initialized `appInsights` instance

3. **logGenerator.js** - Log generation engine
   - Manages multiple concurrent generation jobs
   - Supports three modes: standard, burst, continuous
   - Generates logs, custom metrics, and custom events
   - Uses `appInsights.defaultClient` for telemetry
   - Implements async generation with configurable parameters

### API Flow

```
HTTP Request → app.js → LogGenerator → Application Insights SDK → Azure
                 ↓
           Status/Control
```

### Key Design Patterns

- **Job Management**: Each generation request creates a job with unique ID, tracked in `activeJobs` Map
- **Async Generation**: Uses `setImmediate()` and `setTimeout()` for non-blocking operations
- **Batching**: Flushes telemetry every 100 logs to ensure delivery
- **Resource Cleanup**: Proper job cancellation and shutdown handling

## Deployment

### GitHub Actions
- Workflow at `.github/workflows/azure-deploy.yml`
- Triggers on push to main branch
- Requires secrets: `AZURE_WEBAPP_PUBLISH_PROFILE`, `AZURE_RESOURCE_GROUP`, `APPLICATIONINSIGHTS_CONNECTION_STRING`

### Azure Resources
- ARM template at `azure/azuredeploy.json`
- Creates: Log Analytics Workspace, Application Insights, App Service Plan, App Service
- Default SKU: B1 (upgradeable)
- PowerShell deployment: `./azure/deploy.ps1`

### Environment Variables
Required:
- `APPLICATIONINSIGHTS_CONNECTION_STRING` - Full connection string with InstrumentationKey and endpoints

Optional:
- `APP_INSIGHTS_DAILY_CAP_GB` - Expected cap (informational only)
- `PORT` - Server port (default: 8080)
- `LOG_GENERATION_MAX_THREADS` - Max parallel threads
- `ENABLE_CUSTOM_METRICS` - Send metrics (default: true)
- `ENABLE_CUSTOM_EVENTS` - Send events (default: true)

## API Endpoints

- `POST /generate-logs` - Generate specific number of logs
  - Parameters: count, interval, level, messageSize, includeMetrics, includeEvents
  
- `POST /burst-logs` - Maximum speed generation
  - Parameters: duration, threadsCount
  
- `POST /continuous-logs` - Start/stop sustained generation
  - Parameters: action (start/stop), logsPerSecond, config

- `GET /status` - Current generation statistics
- `POST /stop-all` - Emergency stop all jobs

## Testing Daily Cap Scenarios

The application is designed to test:
1. **Gradual increase** - Start low, increase rate over time
2. **Burst testing** - Maximum generation to quickly hit cap
3. **Mixed telemetry** - Logs + metrics + events counting toward cap
4. **Sustained load** - Continuous generation at specific rate

Monitor via:
- Application `/status` endpoint
- Azure Portal: Application Insights > Usage and estimated costs
- Azure CLI: `az monitor app-insights component billing show`

## Important Considerations

1. **Daily Cap Behavior**: Caps can't stop collection precisely - expect overflow, especially at high volumes
2. **Workspace-based AI**: Uses lesser of Application Insights and Log Analytics caps
3. **Regional Endpoints**: If using regional connection strings, caps apply per region
4. **Performance**: For burst testing, use B2+ App Service tier